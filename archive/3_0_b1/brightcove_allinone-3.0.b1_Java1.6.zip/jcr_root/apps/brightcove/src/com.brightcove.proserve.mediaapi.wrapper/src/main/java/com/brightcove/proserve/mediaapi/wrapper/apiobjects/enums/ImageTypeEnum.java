package com.brightcove.proserve.mediaapi.wrapper.apiobjects.enums;

public enum ImageTypeEnum {
	THUMBNAIL, VIDEO_STILL
}
