package com.brightcove.proserve.mediaapi.wrapper.apiobjects.enums;

public enum SortByTypeEnum {
	PUBLISH_DATE, CREATION_DATE, MODIFIED_DATE, PLAYS_TOTAL, PLAYS_TRAILING_WEEK, DISPLAY_NAME
}
