package com.brightcove.proserve.mediaapi.wrapper.apiobjects.enums;

public enum ControllerTypeEnum {
	LIMELIGHT_LIVE, AKAMAI_LIVE, DEFAULT
}
