package com.brightcove.proserve.mediaapi.wrapper.apiobjects.enums;

public enum PlaylistTypeEnum {
	OLDEST_TO_NEWEST, NEWEST_TO_OLDEST, ALPHABETICAL, PLAYSTOTAL, PLAYS_TRAILING_WEEK, EXPLICIT
}
