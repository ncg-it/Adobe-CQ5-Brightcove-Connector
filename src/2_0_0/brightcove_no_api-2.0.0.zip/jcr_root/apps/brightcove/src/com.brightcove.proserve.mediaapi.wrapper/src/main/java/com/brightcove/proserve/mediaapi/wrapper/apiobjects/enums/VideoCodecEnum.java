package com.brightcove.proserve.mediaapi.wrapper.apiobjects.enums;

public enum VideoCodecEnum {
	NONE,
	SORENSON,
	ON2,
	H264;
}
